🇲🇳 Монгол гарын байрлал (macOS) - Суулгах заавар
Хувилбар: Tsengel mn-custom & Mongolian Script (All-in-One Dual-Layout)

Суулгах алхам:
1. "Keyboard Installer.app"-ийг давхар товшиж нээнэ.
2. "Mongolian.bundle"-ийг уг Installer цонх руу чирч тавина ("Install for current user" сонгоно).
3. "Fonts" хавтас дахь фонтуудыг суулгана (давхар товшиж "Install" дарах эсвэл ~/Library/Fonts руу хуулна).
4. ЧУХАЛ: Системээс заавал 1 удаа гарч (Log out) дахин орно (эсвэл компьютерээ Restart хийнэ).
5. System Settings -> Keyboard -> Input Sources руу орж "+" товч дарна.
6. "Mongolian" хэсгээс дараах хоёр гарыг нэмнэ:
   - "Mongolian (Cyrillic - Tsengel)"
   - "Mongolian Script (Traditional - Tsengel)"
7. Хооронд нь Ctrl + Space эсвэл Globe 🌐 товчоор шууд шилжинэ.

Гараар суулгах арга:
- Finder-ийн Go цэснээс "Go to Folder" (Command + Shift + G) дарж:
  ~/Library/Keyboard Layouts/
  гэж бичээд "Mongolian.bundle"-ийг хуулна.
- Фонтуудыг ~/Library/Fonts/ хавтас руу хуулна.
- Заавал 1 удаа Log Out эсвэл Restart хийнэ.
