🇲🇳 Бүх Нийтийн Монгол Гарын Байрлал (macOS)
=============================================================

СУУЛГАХ АЛХМУУД (Apple Native DMG):

1. Энэ цонхон доторх "Mongolian.bundle"-ийг хажуугийн
   "Keyboard Layouts" холбоос руу чирж хуулна (Drag & Drop).
   (Mac танаас админ нууц үгээ оруулахыг асуувал зөвшөөрнө).

2. Монгол бичгийн фонтуудыг суулгах:
   "Fonts" хавтас доторх .ttf файлуудыг "Fonts (System)" холбоос
   руу чирж хуулна (эсвэл фонт дээр 2 дарж "Install Font").

3. Суулгаж дуусаад энэхүү "Mongolian Keyboard" дискийг 
   Eject (Unmount) хийж хаана.

=============================================================
ИДЭВХЖҮҮЛЭХ:
1. System Settings -> Keyboard -> Text Input (Input Sources) -> Edit.
2. "+" товч дарж Mongolian хэсгээс "Mongolian Cyrillic Ergonomic (Tsengel)"
   эсвэл бусад хувилбаруудыг сонгоод "Add" товшино.
3. (Шинэ гарын драйвер шууд харагдахгүй бол 1 удаа Log out хийгээд буцаж орно).

Төслийн албан ёсны хуудас: https://mn.tsengel.de
Нээлттэй эх код: https://github.com/Tsengel-de/mn-keyboard-layout
