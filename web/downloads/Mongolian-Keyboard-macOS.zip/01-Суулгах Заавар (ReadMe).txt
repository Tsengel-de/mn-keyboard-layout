🇲🇳 Монгол гарын байрлал (macOS) - Суулгах заавар
Хувилбар: Bachka mn-custom & Mongolian Script (All-in-One Dual-Layout)

Хамгийн хялбар арга:
1. "Keyboard Installer.app"-ийг давхар товшиж нээнэ.
2. "Mongolian.bundle"-ийг уг Installer цонх руу чирч тавина.
3. ЧУХАЛ: Системээс заавал 1 удаа гарч (Log out) дахин орно (эсвэл компьютерээ дахин ачаална/restart).
4. System Settings -> Keyboard -> Input Sources руу орж "+" товч дарна.
5. "Mongolian" (эсвэл "Others") дотроос:
   - "Mongolian Cyrillic (Bachka)"
   - "Mongolian Script (Bachka)"
   сонгож Add дарна.
6. Хооронд нь Ctrl + Space эсвэл Globe 🌐 товчоор шууд шилжинэ.

Гараар суулгах арга:
- Finder-ийн Go цэснээс "Go to Folder" (Command + Shift + G) дарж:
  ~/Library/Keyboard Layouts/
  гэж бичээд "Mongolian.bundle" эсвэл .keylayout файлуудыг хуулна.
- Фонтуудыг ~/Library/Fonts/ хавтас руу хуулна.
- Заавал 1 удаа Log Out эсвэл Restart хийнэ.
