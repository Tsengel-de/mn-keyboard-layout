🇲🇳 Монгол гарын байрлал (macOS) - Суулгах заавар
Хувилбар: Tsengel mn-custom & Mongolian Script (All-in-One Dual-Layout)

1. ГАРЫН БАЙРЛАЛ СУУЛГАХ:
   - "Keyboard Installer.app"-ийг давхар товшиж нээнэ.
   - "Mongolian.bundle"-ийг уг Installer цонх руу чирч тавина ("Install for current user" сонгоно).

2. МОНГОЛ БИЧГИЙН ФОНТУУД СУУЛГАХ:
   - Арга А (Терминалаас нэг командаар):
     cp /Volumes/Mongolian\ Keyboard/Fonts/*.ttf ~/Library/Fonts/
   - Арга Б (Font Book аппаар):
     "Fonts" хавтас руу ороод бүх файлуудыг сонгон (Command + A) давхар товшиж "Install" дарна.

3. ИДЭВХЖҮҮЛЭХ:
   - ЧУХАЛ: Системээс заавал 1 удаа гарч (Log out) дахин орно (эсвэл компьютерээ Restart хийнэ).
   - System Settings -> Keyboard -> Input Sources руу орж "+" товч дарна.
   - "Mongolian" хэсгээс дараах хоёр гарыг нэмнэ:
     • "Mongolian (Cyrillic - Tsengel)"
     • "Mongolian Script (Traditional - Tsengel)"
   - Хооронд нь Ctrl + Space эсвэл Globe 🌐 товчоор шууд шилжинэ.

Терминалаас гар болон фонтыг бүрэн суулгах команд:
  mkdir -p ~/Library/Fonts ~/Library/Keyboard\ Layouts
  cp -R /Volumes/Mongolian\ Keyboard/Mongolian.bundle ~/Library/Keyboard\ Layouts/
  cp /Volumes/Mongolian\ Keyboard/Fonts/*.ttf ~/Library/Fonts/
