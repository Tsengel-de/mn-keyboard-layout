🇲🇳 Монгол гарын байрлал (macOS) - Суулгах заавар

Хамгийн хялбар арга:
1. "Keyboard Installer.app"-ийг давхар товшиж нээнэ.
2. "Mongolian.bundle"-ийг уг Installer цонх руу чирч тавина.
3. Системээс нэг удаа гарч (Log out) дахин орно (эсвэл компьютероо дахин ачаална).
4. System Settings -> Keyboard -> Input Sources руу орж "+" товч дарна.
5. "Mongolian" хайж "Mongolian Cyrillic Ergonomic (Tsengel)" сонгож Add дарна.

Гараар суулгах арга:
- Finder-ийн Go цэснээс "Go to Folder" (Command + Shift + G) дарж:
  ~/Library/Keyboard Layouts/
  гэж бичээд "Mongolian.bundle" эсвэл "MongolianCyrillicErgonomic.keylayout" файлыг хуулна.
