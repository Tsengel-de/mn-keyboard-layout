🇲🇳 Бүх Нийтийн Монгол Гарын Байрлал (macOS)
===================================================

СУУЛГАХ АЛХМУУД (Apple Native Drag & Drop):

1. "Mongolian.bundle"-ийг хажуугийн "Keyboard Layouts" холбоос руу чирж хуулна.
   (Mac танаас админ нууц үгээ оруулахыг асуувал зөвшөөрнө үү).

2. Монгол бичгийн фонтуудыг суулгах:
   "Fonts" хавтас руу ороод .ttf файлууд дээр 2 дарж "Install Font" дарна.
   (Эсвэл "Fonts (System)" холбоос руу чирж хуулж болно).

3. ИДЭВХЖҮҮЛЭХ:
   - System Settings -> Keyboard -> Text Input (Input Sources) -> Edit товшино.
   - "+" товч дарж Mongolian хэсгээс "Mongolian Cyrillic Ergonomic (Tsengel)"-ийг
     сонгоод "Add" товшино.
   - (Шууд харагдахгүй бол 1 удаа Log out хийгээд буцаж орно).

Төслийн албан ёсны хуудас: https://mn.tsengel.de
Эх код: https://github.com/Tsengel-de/mn-keyboard-layout
